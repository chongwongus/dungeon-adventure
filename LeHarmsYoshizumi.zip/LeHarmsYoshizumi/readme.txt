-what each person did and what time each person spent

Preston Harms - Unit testing, general debugging, item classes. I spent about 10 hours in total refactoring the dungeon creation into factories and working towards using the observer pattern for potions. I also did some debugging when the application UI was throwing exceptions.

Ainsley Yoshizumi - only worked on the Dungeon class. I wrote my only dungeon class that I spent roughly 5 hours over the course of two days on, it ended up being taken over by my group members and the final version published is not my original code but with the help of my group members, was guided to a more comprehensive and simpler solution my original work. Additionally I conducted code reviews and ran tests likely totaling in 3-4 hours. My group members did an amazing job writing clean and readable code, showing me different ways to accomplish the job of putting together a full video game and GUI. I want to give a special appreciation to Richard for taking the group lead and being super proactive in getting the work done.

Richard Le - Created the GUI and CMD game implementation. Organized the group project and created the initial repo for work. Created the initial Dungeon creation class and code.

-shortcomings listed if any
    * N/A
-extra credit considerations listed
    * GUI complete
    * DFS implimentation of Dungeon