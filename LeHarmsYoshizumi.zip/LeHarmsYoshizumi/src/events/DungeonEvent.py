from enum import Enum

class DungeonEvent(Enum):
    VISION_POTION_USED = "Player has used a vision potion."
