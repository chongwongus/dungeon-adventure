from DungeonAdventure import DungeonAdventure

if __name__ == "__main__":
    game = DungeonAdventure()
    game.play_game()